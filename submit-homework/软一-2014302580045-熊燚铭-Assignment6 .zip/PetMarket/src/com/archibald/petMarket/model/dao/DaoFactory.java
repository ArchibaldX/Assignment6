package com.archibald.petMarket.model.dao;

import java.util.WeakHashMap;

import com.archibald.petMarket.model.dao.impl.OrderDaoImpl;
import com.archibald.petMarket.model.dao.impl.OrderItemDaoImpl;
import com.archibald.petMarket.model.dao.impl.PetDaoImpl;
import com.archibald.petMarket.model.dao.impl.UserDaoImpl;

@SuppressWarnings("rawtypes")
public final class DaoFactory {
	private final static WeakHashMap<String, ICommonDao> map 
		= new WeakHashMap<>();
	public  static ICommonDao getDao(String name){
		ICommonDao dao = map.get(name);
		if(dao!=null){
			return dao;
		}
		return createDao(name);
	}
	private synchronized static ICommonDao createDao(String name) {
		ICommonDao dao = null;
		if("pet".equals(name)){
			dao = new PetDaoImpl();
			map.put(name, dao);
		}
		if("user".equals(name)){
			dao = new UserDaoImpl();
			map.put(name, dao);
		}
		if("order".equals(name)){
			dao=new OrderDaoImpl();
			map.put(name, dao);
		}
		if("orderitem".equals(name)){
			dao=new OrderItemDaoImpl();
			map.put(name, dao);
		}
		
		
		return dao;
	}


}
