package com.archibald.petMarket.model.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.archibald.petMarket.common.JDBCTemplate;
import com.archibald.petMarket.common.JDBCTemplate.PreparedStatementSetter;
import com.archibald.petMarket.common.JDBCTemplate.RowCallBackHandler;
import com.archibald.petMarket.model.entity.OrderItem;

public class OrderItemDaoImpl extends CommonDaoImpl<OrderItem> {

	@Override
	public int save(final OrderItem t) {

		return JDBCTemplate.update(
				"insert into orderitem(orderid,petid,quantity,price) values(?,?,?,?);", 
				new PreparedStatementSetter() {
					
					@Override
					public void setValues(PreparedStatement pstmt) throws SQLException {
						pstmt.setInt(1,t.getOrderid());
						pstmt.setInt(2, t.getPetid());
						pstmt.setInt(3, t.getQuantity());
						pstmt.setInt(4, t.getPrice());
					}
				});
	}
	
	
	@Override
	public int[] betch(OrderItem... instances) {
		return JDBCTemplate.batch(
				"insert into orderitem(orderid,petid,quantity,price) values(?,?,?,?);", 
				createSetters(instances));
	}
	
	
	
	

	@Override
	public List<OrderItem> findByConditions(final String... conditions) {
		return JDBCTemplate.query(
				"select * from orderitem where orderid =?;", 
				new PreparedStatementSetter() {
					
					@Override
					public void setValues(PreparedStatement pstmt) throws SQLException {
						pstmt.setInt(1, Integer.parseInt(conditions[0]));
					}
				}, 
				createHandler());
	}





	private RowCallBackHandler<OrderItem> createHandler() {
		return new RowCallBackHandler<OrderItem>() {
			
			@Override
			public OrderItem processRow(ResultSet rs) throws SQLException {
				OrderItem item = new OrderItem();
				item.setPetid(rs.getInt("petid"));
				item.setOrderid(rs.getInt("orderid"));
				item.setQuantity(rs.getInt("quantity"));
				item.setPrice(rs.getInt("price"));
				return item; 
			}	
		};
	}





	private PreparedStatementSetter[] createSetters(final OrderItem... instances) {
		PreparedStatementSetter[] setters = new PreparedStatementSetter[instances.length];
		for(int i=0,len=instances.length;i<len;i++){
			final OrderItem item =instances[i];
			setters[i] = new PreparedStatementSetter() {
				
				@Override
				public void setValues(PreparedStatement pstmt) throws SQLException {
					pstmt.setInt(1, item.getOrderid());
					pstmt.setInt(2, item.getPetid());
					pstmt.setInt(3, item.getQuantity());
				}
			};
		}

		return null;
	}
	
}
