package com.archibald.petMarket.model.service;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import com.archibald.petMarket.model.entity.CartItem;
import com.archibald.petMarket.model.entity.Pet;

public class Cart {
	private Map<Integer,CartItem> cart = new HashMap<>();
	
	public void add(Pet pet){
		CartItem item = cart.get(pet.getId());
		if(item == null){
			cart.put(pet.getId(), new CartItem(pet));
		}else{
			item.setQuantity(item.getQuantity()+1);
		}
	}
	
	
	public void remove(int id){
		cart.remove(id);
	}
	
	public void changeQuantity(int id,int quantity){
		CartItem item = cart.get(id);
		if(item!=null){
			int count = item.getQuantity()+quantity;
			if(count<1)
				cart.remove(id);
			else
				item.setQuantity(quantity);
		}
	}
	
	public int getTotal(){
		int total=0;
		for(CartItem item:getItems()){
			total+=item.getTotal();
		}
		return total;
	}
	
	public Collection<CartItem> getItems(){
		return cart.values();
	}
	
	
}
