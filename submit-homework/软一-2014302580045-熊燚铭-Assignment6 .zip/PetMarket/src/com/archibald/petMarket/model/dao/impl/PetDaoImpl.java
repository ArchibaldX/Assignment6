package com.archibald.petMarket.model.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.archibald.petMarket.common.JDBCTemplate;
import com.archibald.petMarket.common.JDBCTemplate.PreparedStatementSetter;
import com.archibald.petMarket.common.JDBCTemplate.RowCallBackHandler;
import com.archibald.petMarket.model.entity.Pet;



public class PetDaoImpl extends CommonDaoImpl<Pet> {

	@Override
	public Pet findById(final int id) {
		String sql = "select * from pet where id =?";
		return JDBCTemplate.singleQuery(sql, new PreparedStatementSetter() {
			
			@Override
			public void setValues(PreparedStatement pstmt) throws SQLException {
				pstmt.setInt(1, id);
			}
		}, createHandler());
	}

	private RowCallBackHandler<Pet> createHandler() {
		
		return new RowCallBackHandler<Pet>() {
			@Override
			public Pet processRow(ResultSet rs) throws SQLException {
				Pet pet = new Pet();
				pet.setDrink(rs.getString("drink"));
				pet.setEat(rs.getString("eat"));
				pet.setHobby(rs.getString("hobby"));
				pet.setId(rs.getInt("id"));
				pet.setLive(rs.getString("live"));
				pet.setName(rs.getString("name"));
				pet.setImage(rs.getString("image"));
				pet.setPrice(rs.getInt("price"));
				return pet;
			}
		};
	}

	@Override
	public List<Pet> findAll() {
		return JDBCTemplate.query("select * from pet", createHandler());
	}


}
