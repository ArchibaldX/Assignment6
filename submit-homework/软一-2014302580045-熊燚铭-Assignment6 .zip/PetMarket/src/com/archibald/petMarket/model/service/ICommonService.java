package com.archibald.petMarket.model.service;

import java.io.Serializable;
import java.util.List;


/**
 * @author Archibaldx
 * ��������ӿ�
 * @param <T>
 */
public interface ICommonService <T extends Serializable>{
	List<T> findAll();
	T findById(int id);
	int save(T t);
	List<T> findByConditions(String...condition);
	void consume(T t);
}
