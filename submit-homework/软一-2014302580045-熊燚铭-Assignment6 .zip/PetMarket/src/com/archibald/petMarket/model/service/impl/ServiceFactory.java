package com.archibald.petMarket.model.service.impl;

import java.util.WeakHashMap;

import com.archibald.petMarket.model.service.ICommonService;

/**
 * @author Archibaldx
 * ���ڷ����ʼ��
 */
@SuppressWarnings("rawtypes")
public final class ServiceFactory {
	//���÷�����������
	private final static WeakHashMap<String, ICommonService> map = new WeakHashMap<>();
		
	/**
	 * @param name
	 * @return
	 * ��÷���
	 */
	public static ICommonService getService(String name){
		ICommonService service = map.get(name);
		if(service!=null){
			return service;
		}
		return createService(name);
	}
	/**
	 * @param name
	 * @return
	 * ��������
	 */
	private synchronized static ICommonService createService(String name) {
		ICommonService dao = null;
		if("pet".equals(name)){
			dao = new PetServiceImpl();
			map.put(name, dao);
		}
		if("user".equals(name)){
			dao = new UserServiceImpl();
			map.put(name, dao);
		}
		if("order".equals(name)){
			dao = new OrderServiceImpl();
			map.put(name, dao);
		}
		if("orderitem".equals(name)){
			dao = new OrderItemServiceImpl();
			map.put(name, dao);
		}
		return dao;
	}


}
