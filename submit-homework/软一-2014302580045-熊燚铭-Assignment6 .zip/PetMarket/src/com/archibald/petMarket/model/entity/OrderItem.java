package com.archibald.petMarket.model.entity;

import java.io.Serializable;

public class OrderItem implements Serializable {
	private static final long serialVersionUID = -5931139306790174288L;
	private int orderid;
	private int petid;
	private int quantity;
	private int price;
	
	
	
	
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getOrderid() {
		return orderid;
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getPetid() {
		return petid;
	}
	public void setPetid(int petid) {
		this.petid = petid;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
