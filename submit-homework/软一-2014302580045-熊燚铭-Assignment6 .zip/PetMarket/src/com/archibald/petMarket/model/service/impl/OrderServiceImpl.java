package com.archibald.petMarket.model.service.impl;

import java.util.List;

import com.archibald.petMarket.model.dao.DaoFactory;
import com.archibald.petMarket.model.entity.Order;
@SuppressWarnings("unchecked")
public class OrderServiceImpl extends CommonServiceImpl<Order> {

	
	@Override
	public int save(Order t) {
		int id = DaoFactory.getDao("order").save(t);
		return id;
	}

	
	@Override
	public List<Order> findByConditions(String... condition) {
		return DaoFactory.getDao("order").findByConditions(condition);
	}
	
}
