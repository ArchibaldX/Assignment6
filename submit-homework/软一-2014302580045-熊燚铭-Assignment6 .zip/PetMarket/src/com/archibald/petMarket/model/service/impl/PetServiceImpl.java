package com.archibald.petMarket.model.service.impl;

import java.util.List;

import com.archibald.petMarket.model.dao.DaoFactory;
import com.archibald.petMarket.model.entity.Pet;

/**
 * @author Archibaldx
 * �������
 */
@SuppressWarnings("unchecked")
public class PetServiceImpl extends CommonServiceImpl<Pet> {

	
	@Override
	public List<Pet> findAll() {
		return DaoFactory.getDao("pet").findAll();
	}

	@Override
	public Pet findById(int id) {
		return (Pet)DaoFactory.getDao("pet").findById(id);
	}
	
}
