package com.archibald.petMarket.model.entity;

import java.io.Serializable;

public class CartItem implements Serializable{
	private static final long serialVersionUID = -7091778892112353556L;
	
	private Pet pet;
	private int quantity =1;
	
	public CartItem() {
	}
	
	public CartItem(Pet pet) {
		this.pet = pet;
	}
	
	
	
	public Pet getPet() {
		return pet;
	}
	public void setPet(Pet pet) {
		this.pet = pet;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getTotal(){
		return pet.getPrice()*quantity;
	}

}
