package com.archibald.petMarket.model.service.impl;

import java.io.Serializable;
import java.util.List;

import com.archibald.petMarket.model.service.ICommonService;

/**
 * @author Archibaldx
 * ���������
 * @param <T>
 */
public abstract class CommonServiceImpl<T extends Serializable> implements ICommonService<T>{
	@Override
	public List<T> findAll() {
		return null;
	}
	
	@Override
	public T findById(int id) {
		return null;
	}

	@Override
	public int save(T t) {
		return 0;
	}

	@Override
	public List<T> findByConditions(String... condition) {
		return null;
	}

	@Override
	public void consume(T t) {
		// TODO Auto-generated method stub
		
	}
	
	
	
	
}
