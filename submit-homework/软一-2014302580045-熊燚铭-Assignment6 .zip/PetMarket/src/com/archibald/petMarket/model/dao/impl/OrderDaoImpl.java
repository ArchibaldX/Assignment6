package com.archibald.petMarket.model.dao.impl;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.archibald.petMarket.common.JDBCTemplate;
import com.archibald.petMarket.common.JDBCTemplate.PreparedStatementSetter;
import com.archibald.petMarket.common.JDBCTemplate.RowCallBackHandler;
import com.archibald.petMarket.model.entity.Order;
import com.archibald.petMarket.model.entity.OrderItem;
import com.archibald.petMarket.model.service.impl.ServiceFactory;

public class OrderDaoImpl extends CommonDaoImpl<Order> {

	@Override
	public int save(final Order t) {
		int id = JDBCTemplate.update(
				"insert into orders(username,orderid,total) values(?,?,?);", 
				new PreparedStatementSetter() {
					
					@Override
					public void setValues(PreparedStatement pstmt) throws SQLException {
						pstmt.setString(1, t.getUsername());
						pstmt.setInt(2, t.getId());
						pstmt.setInt(3,t.getTotal());
					}
				});
		return id;
	}

	@Override
	public List<Order> findByConditions(final String... conditions) {
		return JDBCTemplate.query(
				"select * from orders where username =?", 
				new PreparedStatementSetter() {
					
					@Override
					public void setValues(PreparedStatement pstmt) throws SQLException {
						pstmt.setString(1, conditions[0]);
					}
				}, 
				createHandler());
	}

	private RowCallBackHandler<Order> createHandler() {
		
		return new RowCallBackHandler<Order>() {
			
			
			@SuppressWarnings("unchecked")
			@Override
			public Order processRow(ResultSet rs) throws SQLException {
				Order order = new Order();
				order.setId(rs.getInt("orderid"));
				order.setUsername(rs.getString("username"));
				order.setTotal(rs.getInt("total"));
				List<OrderItem> list = ServiceFactory.getService("orderitem").findByConditions(order.getId()+"");
				order.setList(list);
				return order;
			}
		};
	}

}






