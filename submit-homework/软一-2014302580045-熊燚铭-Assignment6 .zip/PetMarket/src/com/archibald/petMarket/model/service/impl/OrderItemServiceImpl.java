package com.archibald.petMarket.model.service.impl;

import java.util.List;

import com.archibald.petMarket.model.dao.DaoFactory;
import com.archibald.petMarket.model.entity.OrderItem;

public class OrderItemServiceImpl extends CommonServiceImpl<OrderItem> {

	@SuppressWarnings("unchecked")
	@Override
	public int save(OrderItem t) {
		return DaoFactory.getDao("orderitem").save(t);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<OrderItem> findByConditions(String... condition) {
		return DaoFactory.getDao("orderitem").findByConditions(condition);
	}

}
