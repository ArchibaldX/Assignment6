package com.archibald.petMarket.model.service.impl;

import java.util.List;

import com.archibald.petMarket.model.dao.DaoFactory;
import com.archibald.petMarket.model.entity.Account;

@SuppressWarnings("unchecked")
public class UserServiceImpl extends CommonServiceImpl<Account>{

	@Override
	public Account findById(int id) {
		return (Account)DaoFactory.getDao("user").findById(id);
	}

	@Override
	public int save(Account t) {
		return DaoFactory.getDao("user").save(t);
	}

	@Override
	public List<Account> findByConditions(String... conditions) {
		return DaoFactory.getDao("user").findByConditions(conditions);
	}
	
	@Override
	public void consume(Account t){
		DaoFactory.getDao("user").consume(t);
	}
	
}
