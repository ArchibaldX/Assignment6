package com.archibald.petMarket.web.listener;

import javax.annotation.Resource;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
import javax.sql.DataSource;

import com.archibald.petMarket.common.ConnectionManager;


/**
 * @author Archibaldx
 * ����Context
 */
@WebListener
public class WebContextListener implements ServletContextListener {
	@Resource(lookup="java:/comp/env",name="jdbc/PetMarket")
	private DataSource dataSource;
	
	
	@Override
	public void contextDestroyed(ServletContextEvent evt) {}

	/* (non-Javadoc)
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 * ��ʼ������Դ
	 */
	@Override
	public void contextInitialized(ServletContextEvent evt) {
		ConnectionManager.setDataSource(dataSource);

	}

}
