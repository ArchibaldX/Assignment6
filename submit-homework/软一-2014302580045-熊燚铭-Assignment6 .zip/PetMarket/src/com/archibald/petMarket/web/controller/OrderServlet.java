package com.archibald.petMarket.web.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.archibald.petMarket.model.entity.Account;
import com.archibald.petMarket.model.entity.CartItem;
import com.archibald.petMarket.model.entity.Order;
import com.archibald.petMarket.model.entity.OrderItem;
import com.archibald.petMarket.model.service.Cart;
import com.archibald.petMarket.model.service.impl.ServiceFactory;

@WebServlet("/do/order")
public class OrderServlet extends HttpServlet{
	private static final long serialVersionUID = 30435822304607584L;

	@SuppressWarnings("unchecked")
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		Cart cart = (Cart)req.getSession().getAttribute("cart");
		Account account =(Account)req.getSession().getAttribute("user");
		if(cart==null||cart.getItems().isEmpty()){
			req.setAttribute("order_err", "����Ϊ��");
			req.setAttribute("manager_iframe", "pages/order/cart.jsp");
			getServletContext().getRequestDispatcher("/pages/manager.jsp");
			return;
		}
		List<OrderItem> items=new ArrayList<>();
		int total=0;
		Random random = new Random(System.currentTimeMillis());
		int ran = Math.abs(random.nextInt())%10000000;
		for(CartItem item: cart.getItems()){
			OrderItem orderItem = new OrderItem();
			orderItem.setPrice(item.getTotal());
			orderItem.setOrderid(ran);
			orderItem.setPetid(item.getPet().getId());
			orderItem.setQuantity(item.getQuantity());
			ServiceFactory.getService("orderitem").save(orderItem);
			items.add(orderItem);
			total+=orderItem.getPrice();
		}
		account.setBalance(account.getBalance()-total);
		ServiceFactory.getService("user").consume(account);
		Order order = new Order();
		order.setId(ran);
		order.setUsername(account.getName());
		order.setList(items);
		order.setTotal(total);
		ServiceFactory.getService("order").save(order);
		forward(req, resp, "/pages/manager.jsp");
	}



	@SuppressWarnings("unchecked")
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		Account account =(Account)req.getSession().getAttribute("user");
		List<Order> orders = ServiceFactory.getService("order").findByConditions(account.getName());
		req.setAttribute("orders",orders);
		forward(req, resp, "/pages/order/order.jsp");
	}

	private void forward(HttpServletRequest req, HttpServletResponse resp,String url)
			throws ServletException, IOException {
		getServletContext().getRequestDispatcher(url).forward(req, resp);
	}

}
