package com.archibald.petMarket.web.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.archibald.petMarket.model.entity.Account;
import com.archibald.petMarket.model.service.impl.ServiceFactory;

/**
 * @author Archibaldx
 *
 */
@WebServlet("/do/user")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = -6682688485743316849L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String op = req.getParameter("op");
		String name = req.getParameter("name");
		String password =req.getParameter("password");
		Account account = new Account();
		account.setName(name);
		account.setPassword(password);
		if("register".equals(op)){
			doRegister(req, resp, op, name, account);
		}else if("login".equals(op)){
			doLogin(req,resp,account);
		}
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		forward(req, resp,"/pages/login_register.jsp");
	}



	@SuppressWarnings("unchecked")
	private void doLogin(HttpServletRequest req, HttpServletResponse resp,
			Account account) throws ServletException, IOException {
		List<Account> list = ServiceFactory.getService("user").findByConditions(account.getName());

		if(list.isEmpty()||!list.get(0).getPassword().equals(account.getPassword())){

			req.setAttribute("login_err", "�û������������");
			forward(req, resp,"/pages/login_register.jsp");
			return;
		}

		req.getSession().setAttribute("user", list.get(0));
		resp.sendRedirect(getServletContext().getContextPath()+"/index.jsp");
	}

	@SuppressWarnings("unchecked")
	private void doRegister(HttpServletRequest req, HttpServletResponse resp,
			String op, String name, Account account) throws ServletException,
			IOException {
		if("register".equals(op)){
			//String confirm = 
			String email = req.getParameter("email").trim();
			account.setEmail(email);
			if("".equals(name)){
				req.setAttribute("name_err", "�û�������Ϊ�գ�");
				forward(req, resp,"/pages/login_register.jsp");
				return;
			}
			List<Account> list = ServiceFactory.getService("user").findByConditions(name);
			if(!list.isEmpty()){
				req.setAttribute("name_err", "�û����Ѵ��ڣ�");
				forward(req, resp,"/pages/login_register.jsp");
				return;
			}
			//int row = 
			ServiceFactory.getService("user").save(account);
			req.getSession().setAttribute("user", account);
			//forward(req, resp, "/index.jsp");
			resp.sendRedirect(getServletContext().getContextPath()+"/index.jsp");
		}
	}

	private void forward(HttpServletRequest req, HttpServletResponse resp,String url)
			throws ServletException, IOException {
		getServletContext().getRequestDispatcher(url).forward(req, resp);
	}


}
