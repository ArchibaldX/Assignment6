package com.archibald.petMarket.web.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.archibald.petMarket.model.entity.Pet;
import com.archibald.petMarket.model.service.Cart;
import com.archibald.petMarket.model.service.impl.ServiceFactory;

@WebServlet("/do/cart")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = -5997474868511242778L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		String _id = req.getParameter("id");
		int id = Integer.parseInt(_id);
		String op = req.getParameter("op");
		Cart cart = getCart(req);
		
		
		if("remove".equals(op)){
			cart.remove(id);
		}
		if("add".equals(op)){
			Pet pet =(Pet) ServiceFactory.getService("pet").findById(id);
			cart.add(pet);
		}
		String url=req.getHeader("referer");
		resp.sendRedirect(url);
	}
	
	private Cart getCart(HttpServletRequest req){
		Cart cart = (Cart)req.getSession().getAttribute("cart");
		if(null==cart){
			cart = new Cart();
			req.getSession().setAttribute("cart", cart);
		}
		return cart;
	}
	
	
}
