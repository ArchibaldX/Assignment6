package com.archibald.petMarket.common;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public final class JDBCTemplate {
	public static <T> List<T> query(String sql,
			RowCallBackHandler<T> handler){
		return query(sql, null,handler); 
	}
	
	public static <T> List<T> query(String sql,
			PreparedStatementSetter setter,
			RowCallBackHandler<T> handler){
		ResultSet rs = null;
		List<T> list = null;
		try {
			rs = query(sql, setter);
			if(handler!=null){
				list = new ArrayList<>();
				while(rs.next()){
					list.add(handler.processRow(rs));
				}
			}
		} catch (SQLException e) {
			throw new JDBCTemplateException(e);
		}finally{
			DBUtil.release(rs);
		}
		return list;
	}
	
	public static <T> T singleQuery(String sql,
			RowCallBackHandler<T> handler){
		return singleQuery(sql, null,handler); 
	}
	
	public static <T> T singleQuery(String sql,
			PreparedStatementSetter setter,
			RowCallBackHandler<T> handler){
		ResultSet rs = null;
		try {
			rs = query(sql, setter);
			if(handler!=null &&rs.next()){
				return handler.processRow(rs);
			}
		} catch (SQLException e) {
			throw new JDBCTemplateException(e);
		}finally{
			DBUtil.release(rs);
		}
		return null;
	}
	
	private static ResultSet query(String sql,PreparedStatementSetter setter) throws SQLException{
		PreparedStatement pstmt = ConnectionManager.getConnection().prepareStatement(sql);
		if(null!=setter)setter.setValues(pstmt);
		return pstmt.executeQuery();
	}
	
	public static int[] batch(String sql,PreparedStatementSetter...setters){
		PreparedStatement pstmt = null;
		try {
			pstmt = ConnectionManager.getConnection().prepareStatement(sql);
			for(PreparedStatementSetter setter:setters){
				setter.setValues(pstmt);
			}
			return pstmt.executeBatch();
		} catch (SQLException e) {
			throw new JDBCTemplateException(e);
		}finally{
			DBUtil.release(pstmt);
		}
	}
	
	public static class JDBCTemplateException extends RuntimeException{

		private static final long serialVersionUID = 1246490044523371051L;

		public JDBCTemplateException() {
			super();
		}

		public JDBCTemplateException(String arg0, Throwable arg1, boolean arg2,
				boolean arg3) {
			super(arg0, arg1, arg2, arg3);
		}

		public JDBCTemplateException(String arg0, Throwable arg1) {
			super(arg0, arg1);
		}

		public JDBCTemplateException(String arg0) {
			super(arg0);
		}

		public JDBCTemplateException(Throwable arg0) {
			super(arg0);
		}
		
	}
	
	public static int update(String sql,PreparedStatementSetter setter){
		PreparedStatement pstmt = null;
		
		try {
			pstmt = ConnectionManager.getConnection().prepareStatement(sql);
			if(null!=setter){
				setter.setValues(pstmt);
			}
			int row = pstmt.executeUpdate();
			
			return row;
		} catch (SQLException e) {
			throw new JDBCTemplateException(e);
		}finally{
			DBUtil.release(pstmt);
		}
	}
	

	

	public static interface PreparedStatementSetter{
		void setValues(PreparedStatement pstmt) throws SQLException;
	}
	
	public static interface RowCallBackHandler<T>{
		T processRow(ResultSet rs)throws SQLException;
	}
}
